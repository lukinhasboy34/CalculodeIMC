# CalculoImc
Exemplo de app criado com o Ionic Framework
