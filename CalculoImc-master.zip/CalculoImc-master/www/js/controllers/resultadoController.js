angular.module('calculoImcApp')
.controller('resultadoController', function () {

});
